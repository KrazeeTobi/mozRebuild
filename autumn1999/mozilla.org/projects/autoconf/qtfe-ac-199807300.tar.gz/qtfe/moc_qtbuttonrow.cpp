/****************************************************************************
** QtButtonRow meta object code from reading C++ file 'qtbuttonrow.h'
**
** Created: Sun May 31 02:13:50 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "qtbuttonrow.h"


const char *QtButtonRow::className() const
{
    return "QtButtonRow";
}

QMetaObject *QtButtonRow::metaObj = 0;

void QtButtonRow::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    metaObj = new QMetaObject( "QtButtonRow", "QWidget",
	0, 0,
	0, 0 );
}
