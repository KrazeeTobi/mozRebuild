/****************************************************************************
** QtLabelled meta object code from reading C++ file 'qtlabelled.h'
**
** Created: Sun May 31 02:13:53 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "qtlabelled.h"


const char *QtLabelled::className() const
{
    return "QtLabelled";
}

QMetaObject *QtLabelled::metaObj = 0;

void QtLabelled::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QFrame::metaObject() )
	QFrame::initMetaObject();
    metaObj = new QMetaObject( "QtLabelled", "QFrame",
	0, 0,
	0, 0 );
}
