/****************************************************************************
** QtBookmarksContext meta object code from reading C++ file 'QtBookmarksContext.h'
**
** Created: Mon Apr 13 17:18:25 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtBookmarksContext.h"


const char *QtBookmarksContext::className() const
{
    return "QtBookmarksContext";
}

QMetaObject *QtBookmarksContext::metaObj = 0;

void QtBookmarksContext::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QtContext::metaObject() )
	QtContext::initMetaObject();
    typedef void(QtBookmarksContext::*m1_t0)();
    typedef void(QtBookmarksContext::*m1_t1)();
    typedef void(QtBookmarksContext::*m1_t2)();
    typedef void(QtBookmarksContext::*m1_t3)();
    typedef void(QtBookmarksContext::*m1_t4)();
    typedef void(QtBookmarksContext::*m1_t5)();
    typedef void(QtBookmarksContext::*m1_t6)();
    typedef void(QtBookmarksContext::*m1_t7)();
    typedef void(QtBookmarksContext::*m1_t8)();
    typedef void(QtBookmarksContext::*m1_t9)();
    typedef void(QtBookmarksContext::*m1_t10)();
    typedef void(QtBookmarksContext::*m1_t11)();
    typedef void(QtBookmarksContext::*m1_t12)();
    typedef void(QtBookmarksContext::*m1_t13)();
    typedef void(QtBookmarksContext::*m1_t14)();
    typedef void(QtBookmarksContext::*m1_t15)();
    typedef void(QtBookmarksContext::*m1_t16)();
    typedef void(QtBookmarksContext::*m1_t17)();
    typedef void(QtBookmarksContext::*m1_t18)();
    typedef void(QtBookmarksContext::*m1_t19)();
    typedef void(QtBookmarksContext::*m1_t20)();
    typedef void(QtBookmarksContext::*m1_t21)();
    typedef void(QtBookmarksContext::*m1_t22)();
    typedef void(QtBookmarksContext::*m1_t23)();
    typedef void(QtBookmarksContext::*m1_t24)();
    typedef void(QtBookmarksContext::*m1_t25)();
    typedef void(QtBookmarksContext::*m1_t26)();
    typedef void(QtBookmarksContext::*m1_t27)();
    typedef void(QtBookmarksContext::*m1_t28)();
    typedef void(QtBookmarksContext::*m1_t29)();
    typedef void(QtBookmarksContext::*m1_t30)();
    typedef void(QtBookmarksContext::*m1_t31)();
    typedef void(QtBookmarksContext::*m1_t32)();
    typedef void(QtBookmarksContext::*m1_t33)();
    typedef void(QtBookmarksContext::*m1_t34)();
    typedef void(QtBookmarksContext::*m1_t35)(QListViewItem*);
    typedef void(QtBookmarksContext::*m1_t36)(QListViewItem*,const QPoint&,int);
    typedef void(QtBookmarksContext::*m1_t37)(QListViewItem*);
    m1_t0 v1_0 = &QtBookmarksContext::cmdEditBookmarks;
    m1_t1 v1_1 = &QtBookmarksContext::cmdNewBookmark;
    m1_t2 v1_2 = &QtBookmarksContext::cmdNewFolder;
    m1_t3 v1_3 = &QtBookmarksContext::cmdNewSeparator;
    m1_t4 v1_4 = &QtBookmarksContext::cmdOpenBookmarkFile;
    m1_t5 v1_5 = &QtBookmarksContext::cmdImport;
    m1_t6 v1_6 = &QtBookmarksContext::cmdSaveAs;
    m1_t7 v1_7 = &QtBookmarksContext::cmdOpenSelected;
    m1_t8 v1_8 = &QtBookmarksContext::cmdOpenAddToToolbar;
    m1_t9 v1_9 = &QtBookmarksContext::cmdClose;
    m1_t10 v1_10 = &QtBookmarksContext::cmdExit;
    m1_t11 v1_11 = &QtBookmarksContext::cmdUndo;
    m1_t12 v1_12 = &QtBookmarksContext::cmdRedo;
    m1_t13 v1_13 = &QtBookmarksContext::cmdCut;
    m1_t14 v1_14 = &QtBookmarksContext::cmdCopy;
    m1_t15 v1_15 = &QtBookmarksContext::cmdPaste;
    m1_t16 v1_16 = &QtBookmarksContext::cmdDelete;
    m1_t17 v1_17 = &QtBookmarksContext::cmdSelectAll;
    m1_t18 v1_18 = &QtBookmarksContext::cmdFindInObject;
    m1_t19 v1_19 = &QtBookmarksContext::cmdFindAgain;
    m1_t20 v1_20 = &QtBookmarksContext::cmdSearch;
    m1_t21 v1_21 = &QtBookmarksContext::cmdSearchAddress;
    m1_t22 v1_22 = &QtBookmarksContext::cmdBookmarkProperties;
    m1_t23 v1_23 = &QtBookmarksContext::cmdSortByTitle;
    m1_t24 v1_24 = &QtBookmarksContext::cmdSortByLocation;
    m1_t25 v1_25 = &QtBookmarksContext::cmdSortByDateLastVisited;
    m1_t26 v1_26 = &QtBookmarksContext::cmdSortByDateCreated;
    m1_t27 v1_27 = &QtBookmarksContext::cmdSortAscending;
    m1_t28 v1_28 = &QtBookmarksContext::cmdSortDescending;
    m1_t29 v1_29 = &QtBookmarksContext::cmdBookmarkUp;
    m1_t30 v1_30 = &QtBookmarksContext::cmdBookmarkDown;
    m1_t31 v1_31 = &QtBookmarksContext::cmdBookmarkWhatsNew;
    m1_t32 v1_32 = &QtBookmarksContext::cmdSetToolbarFolder;
    m1_t33 v1_33 = &QtBookmarksContext::cmdSetNewBookmarkFolder;
    m1_t34 v1_34 = &QtBookmarksContext::cmdSetBookmarkMenuFolder;
    m1_t35 v1_35 = &QtBookmarksContext::activateItem;
    m1_t36 v1_36 = &QtBookmarksContext::rightClick;
    m1_t37 v1_37 = &QtBookmarksContext::newSelected;
    QMetaData *slot_tbl = new QMetaData[38];
    slot_tbl[0].name = "cmdEditBookmarks()";
    slot_tbl[1].name = "cmdNewBookmark()";
    slot_tbl[2].name = "cmdNewFolder()";
    slot_tbl[3].name = "cmdNewSeparator()";
    slot_tbl[4].name = "cmdOpenBookmarkFile()";
    slot_tbl[5].name = "cmdImport()";
    slot_tbl[6].name = "cmdSaveAs()";
    slot_tbl[7].name = "cmdOpenSelected()";
    slot_tbl[8].name = "cmdOpenAddToToolbar()";
    slot_tbl[9].name = "cmdClose()";
    slot_tbl[10].name = "cmdExit()";
    slot_tbl[11].name = "cmdUndo()";
    slot_tbl[12].name = "cmdRedo()";
    slot_tbl[13].name = "cmdCut()";
    slot_tbl[14].name = "cmdCopy()";
    slot_tbl[15].name = "cmdPaste()";
    slot_tbl[16].name = "cmdDelete()";
    slot_tbl[17].name = "cmdSelectAll()";
    slot_tbl[18].name = "cmdFindInObject()";
    slot_tbl[19].name = "cmdFindAgain()";
    slot_tbl[20].name = "cmdSearch()";
    slot_tbl[21].name = "cmdSearchAddress()";
    slot_tbl[22].name = "cmdBookmarkProperties()";
    slot_tbl[23].name = "cmdSortByTitle()";
    slot_tbl[24].name = "cmdSortByLocation()";
    slot_tbl[25].name = "cmdSortByDateLastVisited()";
    slot_tbl[26].name = "cmdSortByDateCreated()";
    slot_tbl[27].name = "cmdSortAscending()";
    slot_tbl[28].name = "cmdSortDescending()";
    slot_tbl[29].name = "cmdBookmarkUp()";
    slot_tbl[30].name = "cmdBookmarkDown()";
    slot_tbl[31].name = "cmdBookmarkWhatsNew()";
    slot_tbl[32].name = "cmdSetToolbarFolder()";
    slot_tbl[33].name = "cmdSetNewBookmarkFolder()";
    slot_tbl[34].name = "cmdSetBookmarkMenuFolder()";
    slot_tbl[35].name = "activateItem(QListViewItem*)";
    slot_tbl[36].name = "rightClick(QListViewItem*,const QPoint&,int)";
    slot_tbl[37].name = "newSelected(QListViewItem*)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    slot_tbl[12].ptr = *((QMember*)&v1_12);
    slot_tbl[13].ptr = *((QMember*)&v1_13);
    slot_tbl[14].ptr = *((QMember*)&v1_14);
    slot_tbl[15].ptr = *((QMember*)&v1_15);
    slot_tbl[16].ptr = *((QMember*)&v1_16);
    slot_tbl[17].ptr = *((QMember*)&v1_17);
    slot_tbl[18].ptr = *((QMember*)&v1_18);
    slot_tbl[19].ptr = *((QMember*)&v1_19);
    slot_tbl[20].ptr = *((QMember*)&v1_20);
    slot_tbl[21].ptr = *((QMember*)&v1_21);
    slot_tbl[22].ptr = *((QMember*)&v1_22);
    slot_tbl[23].ptr = *((QMember*)&v1_23);
    slot_tbl[24].ptr = *((QMember*)&v1_24);
    slot_tbl[25].ptr = *((QMember*)&v1_25);
    slot_tbl[26].ptr = *((QMember*)&v1_26);
    slot_tbl[27].ptr = *((QMember*)&v1_27);
    slot_tbl[28].ptr = *((QMember*)&v1_28);
    slot_tbl[29].ptr = *((QMember*)&v1_29);
    slot_tbl[30].ptr = *((QMember*)&v1_30);
    slot_tbl[31].ptr = *((QMember*)&v1_31);
    slot_tbl[32].ptr = *((QMember*)&v1_32);
    slot_tbl[33].ptr = *((QMember*)&v1_33);
    slot_tbl[34].ptr = *((QMember*)&v1_34);
    slot_tbl[35].ptr = *((QMember*)&v1_35);
    slot_tbl[36].ptr = *((QMember*)&v1_36);
    slot_tbl[37].ptr = *((QMember*)&v1_37);
    metaObj = new QMetaObject( "QtBookmarksContext", "QtContext",
	slot_tbl, 38,
	0, 0 );
}
