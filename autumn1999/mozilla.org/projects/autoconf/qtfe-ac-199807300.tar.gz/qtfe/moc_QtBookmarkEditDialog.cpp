/****************************************************************************
** QtBookmarkEditDialog meta object code from reading C++ file 'QtBookmarkEditDialog.h'
**
** Created: Sun May 31 02:13:47 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtBookmarkEditDialog.h"


const char *QtBookmarkEditDialog::className() const
{
    return "QtBookmarkEditDialog";
}

QMetaObject *QtBookmarkEditDialog::metaObj = 0;

void QtBookmarkEditDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QtVBox::metaObject() )
	QtVBox::initMetaObject();
    typedef void(QtBookmarkEditDialog::*m1_t0)();
    typedef void(QtBookmarkEditDialog::*m1_t1)();
    m1_t0 v1_0 = &QtBookmarkEditDialog::okSlot;
    m1_t1 v1_1 = &QtBookmarkEditDialog::cancelSlot;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "okSlot()";
    slot_tbl[1].name = "cancelSlot()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    typedef void(QtBookmarkEditDialog::*m2_t0)();
    typedef void(QtBookmarkEditDialog::*m2_t1)();
    m2_t0 v2_0 = &QtBookmarkEditDialog::okClicked;
    m2_t1 v2_1 = &QtBookmarkEditDialog::cancelClicked;
    QMetaData *signal_tbl = new QMetaData[2];
    signal_tbl[0].name = "okClicked()";
    signal_tbl[1].name = "cancelClicked()";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    metaObj = new QMetaObject( "QtBookmarkEditDialog", "QtVBox",
	slot_tbl, 2,
	signal_tbl, 2 );
}

// SIGNAL okClicked
void QtBookmarkEditDialog::okClicked()
{
    activate_signal( "okClicked()" );
}

// SIGNAL cancelClicked
void QtBookmarkEditDialog::cancelClicked()
{
    activate_signal( "cancelClicked()" );
}
