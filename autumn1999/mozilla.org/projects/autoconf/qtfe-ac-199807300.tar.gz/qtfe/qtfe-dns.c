#include "xp.h"

int
FE_StartAsyncDNSLookup(MWContext *context,
		       char *host_and_port,
		       void **hoststruct_ptr_ret,
		       int socket)
{
    return 0;
}
