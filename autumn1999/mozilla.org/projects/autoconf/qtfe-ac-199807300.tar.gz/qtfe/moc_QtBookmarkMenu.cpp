/****************************************************************************
** QtBookmarkMenu meta object code from reading C++ file 'QtBookmarkMenu.h'
**
** Created: Mon Apr 13 17:18:40 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtBookmarkMenu.h"


const char *QtBookmarkMenu::className() const
{
    return "QtBookmarkMenu";
}

QMetaObject *QtBookmarkMenu::metaObj = 0;

void QtBookmarkMenu::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QPopupMenu::metaObject() )
	QPopupMenu::initMetaObject();
    typedef void(QtBookmarkMenu::*m1_t0)();
    typedef void(QtBookmarkMenu::*m1_t1)(int);
    typedef void(QtBookmarkMenu::*m1_t2)(int);
    typedef void(QtBookmarkMenu::*m1_t3)();
    typedef void(QtBookmarkMenu::*m1_t4)();
    typedef void(QtBookmarkMenu::*m1_t5)();
    typedef void(QtBookmarkMenu::*m1_t6)();
    typedef void(QtBookmarkMenu::*m1_t7)();
    typedef void(QtBookmarkMenu::*m1_t8)();
    typedef void(QtBookmarkMenu::*m1_t9)();
    m1_t0 v1_0 = &QtBookmarkMenu::cmdAddBookmark;
    m1_t1 v1_1 = &QtBookmarkMenu::highlightedSlot;
    m1_t2 v1_2 = &QtBookmarkMenu::activatedSlot;
    m1_t3 v1_3 = &QtBookmarkMenu::beforeShow;
    m1_t4 v1_4 = &QtBookmarkMenu::trollTech;
    m1_t5 v1_5 = &QtBookmarkMenu::guideI;
    m1_t6 v1_6 = &QtBookmarkMenu::guideP;
    m1_t7 v1_7 = &QtBookmarkMenu::guideY;
    m1_t8 v1_8 = &QtBookmarkMenu::guideN;
    m1_t9 v1_9 = &QtBookmarkMenu::guideC;
    QMetaData *slot_tbl = new QMetaData[10];
    slot_tbl[0].name = "cmdAddBookmark()";
    slot_tbl[1].name = "highlightedSlot(int)";
    slot_tbl[2].name = "activatedSlot(int)";
    slot_tbl[3].name = "beforeShow()";
    slot_tbl[4].name = "trollTech()";
    slot_tbl[5].name = "guideI()";
    slot_tbl[6].name = "guideP()";
    slot_tbl[7].name = "guideY()";
    slot_tbl[8].name = "guideN()";
    slot_tbl[9].name = "guideC()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    metaObj = new QMetaObject( "QtBookmarkMenu", "QPopupMenu",
	slot_tbl, 10,
	0, 0 );
}
