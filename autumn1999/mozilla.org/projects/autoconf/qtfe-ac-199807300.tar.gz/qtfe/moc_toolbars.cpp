/****************************************************************************
** UnknownProgress meta object code from reading C++ file 'toolbars.h'
**
** Created: Sat Jun 20 21:23:14 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.23 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error "Moc format conflict - please regenerate all moc files"
#endif

#include "toolbars.h"
#include <qmetaobject.h>


const char *UnknownProgress::className() const
{
    return "UnknownProgress";
}

QMetaObject *UnknownProgress::metaObj = 0;

void UnknownProgress::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QWidget::className(), "QWidget") != 0 )
	badSuperclassWarning("UnknownProgress","QWidget");
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    typedef void(UnknownProgress::*m1_t0)();
    typedef void(UnknownProgress::*m1_t1)();
    m1_t0 v1_0 = &UnknownProgress::progress;
    m1_t1 v1_1 = &UnknownProgress::done;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "progress()";
    slot_tbl[1].name = "done()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    metaObj = new QMetaObject( "UnknownProgress", "QWidget",
	slot_tbl, 2,
	0, 0 );
}


const char *MovieToolButton::className() const
{
    return "MovieToolButton";
}

QMetaObject *MovieToolButton::metaObj = 0;

void MovieToolButton::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QToolButton::className(), "QToolButton") != 0 )
	badSuperclassWarning("MovieToolButton","QToolButton");
    if ( !QToolButton::metaObject() )
	QToolButton::initMetaObject();
    typedef void(MovieToolButton::*m1_t0)();
    typedef void(MovieToolButton::*m1_t1)();
    typedef void(MovieToolButton::*m1_t2)(const QRect&);
    typedef void(MovieToolButton::*m1_t3)(const QSize&);
    m1_t0 v1_0 = &MovieToolButton::start;
    m1_t1 v1_1 = &MovieToolButton::stop;
    m1_t2 v1_2 = &MovieToolButton::movieUpdated;
    m1_t3 v1_3 = &MovieToolButton::movieResized;
    QMetaData *slot_tbl = new QMetaData[4];
    slot_tbl[0].name = "start()";
    slot_tbl[1].name = "stop()";
    slot_tbl[2].name = "movieUpdated(const QRect&)";
    slot_tbl[3].name = "movieResized(const QSize&)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    metaObj = new QMetaObject( "MovieToolButton", "QToolButton",
	slot_tbl, 4,
	0, 0 );
}


const char *Toolbars::className() const
{
    return "Toolbars";
}

QMetaObject *Toolbars::metaObj = 0;

void Toolbars::initMetaObject()
{
    if ( metaObj )
	return;
    if ( strcmp(QObject::className(), "QObject") != 0 )
	badSuperclassWarning("Toolbars","QObject");
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(Toolbars::*m1_t0)(bool);
    typedef void(Toolbars::*m1_t1)(bool);
    typedef void(Toolbars::*m1_t2)(bool);
    typedef void(Toolbars::*m1_t3)(bool);
    typedef void(Toolbars::*m1_t4)(int);
    typedef void(Toolbars::*m1_t5)(int);
    typedef void(Toolbars::*m1_t6)();
    typedef void(Toolbars::*m1_t7)();
    typedef void(Toolbars::*m1_t8)(const char*);
    typedef void(Toolbars::*m1_t9)(const char*);
    typedef void(Toolbars::*m1_t10)();
    typedef void(Toolbars::*m1_t11)();
    m1_t0 v1_0 = &Toolbars::setBackButtonEnabled;
    m1_t1 v1_1 = &Toolbars::setForwardButtonEnabled;
    m1_t2 v1_2 = &Toolbars::setLoadImagesButtonEnabled;
    m1_t3 v1_3 = &Toolbars::setStopButtonEnabled;
    m1_t4 v1_4 = &Toolbars::setupProgress;
    m1_t5 v1_5 = &Toolbars::signalProgress;
    m1_t6 v1_6 = &Toolbars::signalProgress;
    m1_t7 v1_7 = &Toolbars::endProgress;
    m1_t8 v1_8 = &Toolbars::setMessage;
    m1_t9 v1_9 = &Toolbars::setComboText;
    m1_t10 v1_10 = &Toolbars::visitMozilla;
    m1_t11 v1_11 = &Toolbars::hideProgressBars;
    QMetaData *slot_tbl = new QMetaData[12];
    slot_tbl[0].name = "setBackButtonEnabled(bool)";
    slot_tbl[1].name = "setForwardButtonEnabled(bool)";
    slot_tbl[2].name = "setLoadImagesButtonEnabled(bool)";
    slot_tbl[3].name = "setStopButtonEnabled(bool)";
    slot_tbl[4].name = "setupProgress(int)";
    slot_tbl[5].name = "signalProgress(int)";
    slot_tbl[6].name = "signalProgress()";
    slot_tbl[7].name = "endProgress()";
    slot_tbl[8].name = "setMessage(const char*)";
    slot_tbl[9].name = "setComboText(const char*)";
    slot_tbl[10].name = "visitMozilla()";
    slot_tbl[11].name = "hideProgressBars()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    slot_tbl[8].ptr = *((QMember*)&v1_8);
    slot_tbl[9].ptr = *((QMember*)&v1_9);
    slot_tbl[10].ptr = *((QMember*)&v1_10);
    slot_tbl[11].ptr = *((QMember*)&v1_11);
    typedef void(Toolbars::*m2_t0)(const char*);
    m2_t0 v2_0 = &Toolbars::openURL;
    QMetaData *signal_tbl = new QMetaData[1];
    signal_tbl[0].name = "openURL(const char*)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    metaObj = new QMetaObject( "Toolbars", "QObject",
	slot_tbl, 12,
	signal_tbl, 1 );
}

// SIGNAL openURL
void Toolbars::openURL( const char* t0 )
{
    activate_signal( "openURL(const char*)", t0 );
}
