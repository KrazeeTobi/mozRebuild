/*
 * The contents of this file are subject to the Mozilla Public
 * License Version 1.1 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.mozilla.org/MPL/
 * 
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 * 
 * The Original Code is the Netscape security libraries.
 * 
 * The Initial Developer of the Original Code is Netscape
 * Communications Corporation.  Portions created by Netscape are 
 * Copyright (C) 1994-2000 Netscape Communications Corporation.  All
 * Rights Reserved.
 * 
 * Contributor(s):
 * 
 * Alternatively, the contents of this file may be used under the
 * terms of the GNU General Public License Version 2 or later (the
 * "GPL"), in which case the provisions of the GPL are applicable 
 * instead of those above.  If you wish to allow use of your 
 * version of this file only under the terms of the GPL and not to
 * allow others to use your version of this file under the MPL,
 * indicate your decision by deleting the provisions above and
 * replace them with the notice and other provisions required by
 * the GPL.  If you do not delete the provisions above, a recipient
 * may use your version of this file under either the MPL or the
 * GPL.
 *
 * keyt.h - public data structures for the private key library
 *
 * $Id: keyt.h,v 1.21 2000/02/11 05:13:12 relyea Exp $
 */

#ifndef _KEYT_H_
#define _KEYT_H_

#include "mcom_db.h"
#include "secasn1t.h"

typedef struct SECKEYEncryptedPrivateKeyInfoStr SECKEYEncryptedPrivateKeyInfo;
typedef struct SECKEYPrivateKeyInfoStr SECKEYPrivateKeyInfo;
typedef struct SECKEYPrivateKeyStr SECKEYPrivateKey;
typedef struct SECKEYPublicKeyStr SECKEYPublicKey;
typedef struct SECKEYLowPrivateKeyStr SECKEYLowPrivateKey;
typedef struct SECKEYLowPublicKeyStr SECKEYLowPublicKey;
typedef struct SECKEYKeyDBHandleStr SECKEYKeyDBHandle;
typedef struct SECKEYDBKeyStr SECKEYDBKey;
typedef struct SECKEYAttributeStr SECKEYAttribute;

#include "secmodt.h"
#include "pkcs11t.h"

/*
** Attributes
*/
struct SECKEYAttributeStr {
    SECItem attrType;
    SECItem **attrValue;
};

/*
** A PKCS#8 private key info object
*/
struct SECKEYPrivateKeyInfoStr {
    PRArenaPool *arena;
    SECItem version;
    SECAlgorithmID algorithm;
    SECItem privateKey;
    SECKEYAttribute **attributes;
};
#define SEC_PRIVATE_KEY_INFO_VERSION		0	/* what we *create* */

/*
** A PKCS#8 private key info object
*/
struct SECKEYEncryptedPrivateKeyInfoStr {
    PRArenaPool *arena;
    SECAlgorithmID algorithm;
    SECItem encryptedData;
};

typedef enum { nullKey, rsaKey, dsaKey, fortezzaKey,
               dhKey, keaKey } KeyType;

typedef struct RSAPublicKeyStr RSAPublicKey;
typedef struct RSAPrivateKeyStr RSAPrivateKey;

struct RSAPublicKeyStr {
    SECItem modulus;
    SECItem publicExponent;
};

struct RSAPrivateKeyStr {
    SECItem modulus;
    SECItem version;
    SECItem publicExponent;
    SECItem privateExponent;
    SECItem prime[2];
    SECItem primeExponent[2];
    SECItem coefficient;
};

typedef struct PQGParamsStr PQGParams;
typedef struct DiffPQGParamsStr DiffPQGParams;
typedef struct DSAPublicKeyStr DSAPublicKey;
typedef struct DSAPrivateKeyStr DSAPrivateKey;
typedef struct KEAParamsStr KEAParams;
typedef struct KEAPublicKeyStr KEAPublicKey;

typedef struct PQGDualParamsStr PQGDualParams;

struct PQGParamsStr {
    PRArenaPool *arena;
    SECItem prime;    /* p */
    SECItem subPrime; /* q */
    SECItem base;     /* g */
};

struct DiffPQGParamsStr {
    PQGParams DiffKEAParams;
    PQGParams DiffDSAParams;
};

struct PQGDualParamsStr {
    PQGParams CommParams;
    DiffPQGParams DiffParams;
};

struct DSAPublicKeyStr {
    PQGParams params;
    SECItem publicValue;
};

struct DSAPrivateKeyStr {
    PQGParams params;
    SECItem publicValue;
    SECItem privateValue;
};

struct KEAParamsStr {
    PRArenaPool *arena;
    SECItem hash;
};
 
struct KEAPublicKeyStr {
    KEAParams params;
    SECItem publicValue;
};

typedef struct DHPublicKeyStr DHPublicKey;
typedef struct DHPrivateKeyStr DHPrivateKey;
typedef struct DHParamsStr DHParams;

struct DHPublicKeyStr {
    PRArenaPool * arena;
    SECItem base;
    SECItem prime;
    SECItem publicValue;
};

struct DHPrivateKeyStr {
    PRArenaPool * arena;
    SECItem base;
    SECItem prime;
    SECItem privateValue;
    SECItem publicValue;
};

struct DHParamsStr {
    PRArenaPool * arena;
    SECItem base; /* g */
    SECItem prime; /* p */
};
typedef struct FortezzaPublicKeyStr FortezzaPublicKey;
typedef struct FortezzaPrivateKeyStr FortezzaPrivateKey;

struct FortezzaPublicKeyStr {
    int      KEAversion;
    int      DSSversion;
    unsigned char    KMID[8];
    SECItem clearance;
    SECItem KEApriviledge;
    SECItem DSSpriviledge;
    SECItem KEAKey;
    SECItem DSSKey;
    PQGParams params;
    PQGParams keaParams;
};

struct FortezzaPrivateKeyStr {
     int certificate;
     unsigned char serial[8];
     int socket;
};

/*
** An RSA public key object.
*/
struct SECKEYLowPublicKeyStr {
    PRArenaPool *arena;
    KeyType keyType ;
    union {
        RSAPublicKey rsa;
	DSAPublicKey dsa;
	DHPublicKey  dh;
    } u;
};

/*
** A Generic  public key object.
*/
struct SECKEYPublicKeyStr {
    PRArenaPool *arena;
    KeyType keyType;
    PK11SlotInfo *pkcs11Slot;
    CK_OBJECT_HANDLE pkcs11ID;
    union {
        RSAPublicKey rsa;
	DSAPublicKey dsa;
	DHPublicKey  dh;
        KEAPublicKey kea;
        FortezzaPublicKey fortezza;
    } u;
};

/*
** Low Level private key object
** This is only used by the raw Crypto engines (crypto), keydb (keydb),
** and PKCS #11. Everyone else uses the high level key structure.
*/
struct SECKEYLowPrivateKeyStr {
    PRArenaPool *arena;
    KeyType keyType;
    union {
        RSAPrivateKey rsa;
	DSAPrivateKey dsa;
	DHPrivateKey  dh;
        FortezzaPrivateKey fortezza; /* includes DSA and KEA private
                                        keys used with fortezza      */
    } u;
};

/*
** A generic key structure
*/ 
struct SECKEYPrivateKeyStr {
    PRArenaPool *arena;
    KeyType keyType;
    PK11SlotInfo *pkcs11Slot;	/* pkcs11 slot this key lives in */
    CK_OBJECT_HANDLE pkcs11ID;  /* ID of pkcs11 object */
    PRBool pkcs11IsTemp;	/* temp pkcs11 object, delete it when done */
    void *wincx;		/* context for errors and pw prompts */
};

/*
 * a key in/for the data base
 */
struct SECKEYDBKeyStr {
    PRArenaPool *arena;
    int version;
    char *nickname;
    SECItem salt;
    SECItem derPK;
};

/*
 * Handle structure for open key databases
 */
struct SECKEYKeyDBHandleStr {
    DB *db;
    DB *updatedb;		/* used when updating an old version */
    SECItem *global_salt;	/* password hashing salt for this db */
    int version;		/* version of the database */
    PRBool dialog_pending;	/* is the "setup password" dialog up? */
    PRBool checked;
};

#define PRIVATE_KEY_DB_FILE_VERSION 3

#define SEC_PRIVATE_KEY_VERSION			0	/* what we *create* */

/*
** Typedef for callback to get a password "key".
*/
typedef SECItem * (* SECKEYGetPasswordKey)(void *arg,
					   SECKEYKeyDBHandle *handle);

/*
** Typedef for callback for traversing key database.
**      "key" is the key used to index the data in the database (nickname)
**      "data" is the key data
**      "pdata" is the user's data 
*/
typedef SECStatus (* SECKEYTraverseKeysFunc)(DBT *key, DBT *data, void *pdata);

extern const SEC_ASN1Template SECKEY_EncryptedPrivateKeyInfoTemplate[];
extern const SEC_ASN1Template SECKEY_RSAPublicKeyTemplate[];
extern const SEC_ASN1Template SECKEY_RSAPrivateKeyTemplate[];
extern const SEC_ASN1Template SECKEY_DSAPublicKeyTemplate[];
extern const SEC_ASN1Template SECKEY_DSAPrivateKeyTemplate[];
extern const SEC_ASN1Template SECKEY_DSAPrivateKeyExportTemplate[];
extern const SEC_ASN1Template SECKEY_DHPrivateKeyTemplate[];
extern const SEC_ASN1Template SECKEY_DHPrivateKeyExportTemplate[];
extern const SEC_ASN1Template SECKEY_PrivateKeyInfoTemplate[];
extern const SEC_ASN1Template SECKEY_DHPublicKeyTemplate[];
extern const SEC_ASN1Template SECKEY_DHParamKeyTemplate[];
extern const SEC_ASN1Template SECKEY_PointerToEncryptedPrivateKeyInfoTemplate[];
extern const SEC_ASN1Template SECKEY_PointerToPrivateKeyInfoTemplate[];
extern const SEC_ASN1Template SECKEY_PQGParamsTemplate[];
extern const SEC_ASN1Template SECKEY_AttributeTemplate[];

#endif /* _KEYT_H_ */
