/****************************************************************************
** OpenDialog meta object code from reading C++ file 'OpenDialog.h'
**
** Created: Mon Apr 13 17:18:14 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "OpenDialog.h"


const char *OpenDialog::className() const
{
    return "OpenDialog";
}

QMetaObject *OpenDialog::metaObj = 0;

void OpenDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(OpenDialog::*m1_t0)();
    typedef void(OpenDialog::*m1_t1)();
    typedef void(OpenDialog::*m1_t2)();
    typedef void(OpenDialog::*m1_t3)();
    m1_t0 v1_0 = &OpenDialog::chooseFile;
#ifdef EDITOR
    m1_t1 v1_1 = &OpenDialog::openInComposer;
#endif
    m1_t2 v1_2 = &OpenDialog::openInNavigator;
    m1_t3 v1_3 = &OpenDialog::clear;
    QMetaData *slot_tbl = new QMetaData[4];
    slot_tbl[0].name = "chooseFile()";
#ifdef EDITOR
    slot_tbl[1].name = "openInComposer()";
#endif
    slot_tbl[2].name = "openInNavigator()";
    slot_tbl[3].name = "clear()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
#ifdef EDITOR
    slot_tbl[1].ptr = *((QMember*)&v1_1);
#endif
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    metaObj = new QMetaObject( "OpenDialog", "QDialog",
	slot_tbl, 4,
	0, 0 );
}
