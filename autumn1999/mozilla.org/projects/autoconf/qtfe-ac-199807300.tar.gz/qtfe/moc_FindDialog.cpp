/****************************************************************************
** FindDialog meta object code from reading C++ file 'FindDialog.h'
**
** Created: Mon Apr 13 17:18:11 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "FindDialog.h"


const char *FindDialog::className() const
{
    return "FindDialog";
}

QMetaObject *FindDialog::metaObj = 0;

void FindDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(FindDialog::*m1_t0)();
    typedef void(FindDialog::*m1_t1)();
    m1_t0 v1_0 = &FindDialog::find;
    m1_t1 v1_1 = &FindDialog::clear;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "find()";
    slot_tbl[1].name = "clear()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    metaObj = new QMetaObject( "FindDialog", "QDialog",
	slot_tbl, 2,
	0, 0 );
}
