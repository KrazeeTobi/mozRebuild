/****************************************************************************
** QtPrefItem meta object code from reading C++ file 'QtPrefs.h'
**
** Created: Mon Apr 13 17:18:30 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtPrefs.h"


const char *QtPrefItem::className() const
{
    return "QtPrefItem";
}

QMetaObject *QtPrefItem::metaObj = 0;

void QtPrefItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(QtPrefItem::*m1_t0)(bool);
    m1_t0 v1_0 = &QtPrefItem::setModified;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "setModified(bool)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    metaObj = new QMetaObject( "QtPrefItem", "QObject",
	slot_tbl, 1,
	0, 0 );
}


const char *QtEnumPrefItem::className() const
{
    return "QtEnumPrefItem";
}

QMetaObject *QtEnumPrefItem::metaObj = 0;

void QtEnumPrefItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QtPrefItem::metaObject() )
	QtPrefItem::initMetaObject();
    typedef void(QtEnumPrefItem::*m1_t0)(int);
    m1_t0 v1_0 = &QtEnumPrefItem::setCurrent;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "setCurrent(int)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    metaObj = new QMetaObject( "QtEnumPrefItem", "QtPrefItem",
	slot_tbl, 1,
	0, 0 );
}


const char *QtPreferences::className() const
{
    return "QtPreferences";
}

QMetaObject *QtPreferences::metaObj = 0;

void QtPreferences::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(QtPreferences::*m1_t0)();
    typedef void(QtPreferences::*m1_t1)();
    typedef void(QtPreferences::*m1_t2)();
    m1_t0 v1_0 = &QtPreferences::apply;
    m1_t1 v1_1 = &QtPreferences::cancel;
    m1_t2 v1_2 = &QtPreferences::manualProxyPage;
    QMetaData *slot_tbl = new QMetaData[3];
    slot_tbl[0].name = "apply()";
    slot_tbl[1].name = "cancel()";
    slot_tbl[2].name = "manualProxyPage()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    metaObj = new QMetaObject( "QtPreferences", "QDialog",
	slot_tbl, 3,
	0, 0 );
}


const char *QtPrefPageItem::className() const
{
    return "QtPrefPageItem";
}

QMetaObject *QtPrefPageItem::metaObj = 0;

void QtPrefPageItem::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(QtPrefPageItem::*m2_t0)(int);
    m2_t0 v2_0 = &QtPrefPageItem::activated;
    QMetaData *signal_tbl = new QMetaData[1];
    signal_tbl[0].name = "activated(int)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    metaObj = new QMetaObject( "QtPrefPageItem", "QObject",
	0, 0,
	signal_tbl, 1 );
}

// SIGNAL activated
void QtPrefPageItem::activated( int t0 )
{
    activate_signal( "activated(int)", t0 );
}
