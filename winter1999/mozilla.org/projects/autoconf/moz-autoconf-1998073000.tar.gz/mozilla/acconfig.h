/* package name */
#undef PACKAGE 

/* package version */
#undef VERSION 

/* define whether to include support for https */
#undef HAVE_HTTPS
#define NO_SECURITY !HAVE_HTTPS

/* define which client to build */
#define MOZ_MEDIUM 1

/* must always be defined */
#define MOZILLA_CLIENT 1

/* define if we have do not want md support */
#define NO_MDUPDATE 1

/* define if we want the optimized version */
#undef BUILD_OPT


