/****************************************************************************
** SecurityDialog meta object code from reading C++ file 'SecurityDialog.h'
**
** Created: Mon Apr 13 17:18:34 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "SecurityDialog.h"


const char *SecurityDialog::className() const
{
    return "SecurityDialog";
}

QMetaObject *SecurityDialog::metaObj = 0;

void SecurityDialog::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QDialog::metaObject() )
	QDialog::initMetaObject();
    typedef void(SecurityDialog::*m1_t0)(bool);
    m1_t0 v1_0 = &SecurityDialog::prefsCBToggled;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "prefsCBToggled(bool)";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    metaObj = new QMetaObject( "SecurityDialog", "QDialog",
	slot_tbl, 1,
	0, 0 );
}
