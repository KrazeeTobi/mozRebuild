/****************************************************************************
** QtVBox meta object code from reading C++ file 'qtvbox.h'
**
** Created: Sun May 31 02:13:54 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "qtvbox.h"


const char *QtVBox::className() const
{
    return "QtVBox";
}

QMetaObject *QtVBox::metaObj = 0;

void QtVBox::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QtHBox::metaObject() )
	QtHBox::initMetaObject();
    metaObj = new QMetaObject( "QtVBox", "QtHBox",
	0, 0,
	0, 0 );
}
