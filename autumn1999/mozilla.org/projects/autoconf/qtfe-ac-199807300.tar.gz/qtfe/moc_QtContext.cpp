/****************************************************************************
** QtContext meta object code from reading C++ file 'QtContext.h'
**
** Created: Tue Apr 14 19:23:25 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtContext.h"


const char *QtContext::className() const
{
    return "QtContext";
}

QMetaObject *QtContext::metaObj = 0;

void QtContext::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QObject::metaObject() )
	QObject::initMetaObject();
    typedef void(QtContext::*m1_t0)();
    m1_t0 v1_0 = &QtContext::cmdQuit;
    QMetaData *slot_tbl = new QMetaData[1];
    slot_tbl[0].name = "cmdQuit()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    typedef void(QtContext::*m2_t0)(const char*,int);
    typedef void(QtContext::*m2_t1)();
    typedef void(QtContext::*m2_t2)(int);
    typedef void(QtContext::*m2_t3)(int);
    typedef void(QtContext::*m2_t4)();
    typedef void(QtContext::*m2_t5)();
    typedef void(QtContext::*m2_t6)(const char*);
    typedef void(QtContext::*m2_t7)(bool);
    typedef void(QtContext::*m2_t8)(const char*);
    m2_t0 v2_0 = &QtContext::messengerMessage;
    m2_t1 v2_1 = &QtContext::messengerMessageClear;
    m2_t2 v2_2 = &QtContext::progressStarting;
    m2_t3 v2_3 = &QtContext::progressMade;
    m2_t4 v2_4 = &QtContext::progressMade;
    m2_t5 v2_5 = &QtContext::progressFinished;
    m2_t6 v2_6 = &QtContext::progressReport;
    m2_t7 v2_7 = &QtContext::canStop;
    m2_t8 v2_8 = &QtContext::urlChanged;
    QMetaData *signal_tbl = new QMetaData[9];
    signal_tbl[0].name = "messengerMessage(const char*,int)";
    signal_tbl[1].name = "messengerMessageClear()";
    signal_tbl[2].name = "progressStarting(int)";
    signal_tbl[3].name = "progressMade(int)";
    signal_tbl[4].name = "progressMade()";
    signal_tbl[5].name = "progressFinished()";
    signal_tbl[6].name = "progressReport(const char*)";
    signal_tbl[7].name = "canStop(bool)";
    signal_tbl[8].name = "urlChanged(const char*)";
    signal_tbl[0].ptr = *((QMember*)&v2_0);
    signal_tbl[1].ptr = *((QMember*)&v2_1);
    signal_tbl[2].ptr = *((QMember*)&v2_2);
    signal_tbl[3].ptr = *((QMember*)&v2_3);
    signal_tbl[4].ptr = *((QMember*)&v2_4);
    signal_tbl[5].ptr = *((QMember*)&v2_5);
    signal_tbl[6].ptr = *((QMember*)&v2_6);
    signal_tbl[7].ptr = *((QMember*)&v2_7);
    signal_tbl[8].ptr = *((QMember*)&v2_8);
    metaObj = new QMetaObject( "QtContext", "QObject",
	slot_tbl, 1,
	signal_tbl, 9 );
}

#if !defined(Q_MOC_CONNECTIONLIST_DECLARED)
#define Q_MOC_CONNECTIONLIST_DECLARED
#include <qlist.h>
#if defined(Q_DECLARE)
Q_DECLARE(QListM,QConnection);
Q_DECLARE(QListIteratorM,QConnection);
#else
// for compatibility with old header files
declare(QListM,QConnection);
declare(QListIteratorM,QConnection);
#endif
#endif

// SIGNAL messengerMessage
void QtContext::messengerMessage( const char* t0, int t1 )
{
    QConnectionList *clist = receivers("messengerMessage(const char*,int)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(const char*);
    typedef RT1 *PRT1;
    typedef void (QObject::*RT2)(const char*,int);
    typedef RT2 *PRT2;
    RT0 r0;
    RT1 r1;
    RT2 r2;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	    case 2:
		r2 = *((PRT2)(c->member()));
		(object->*r2)(t0, t1);
		break;
	}
    }
}

// SIGNAL messengerMessageClear
void QtContext::messengerMessageClear()
{
    activate_signal( "messengerMessageClear()" );
}

// SIGNAL progressStarting
void QtContext::progressStarting( int t0 )
{
    activate_signal( "progressStarting(int)", t0 );
}

// SIGNAL progressMade
void QtContext::progressMade( int t0 )
{
    activate_signal( "progressMade(int)", t0 );
}

// SIGNAL progressMade
void QtContext::progressMade()
{
    activate_signal( "progressMade()" );
}

// SIGNAL progressFinished
void QtContext::progressFinished()
{
    activate_signal( "progressFinished()" );
}

// SIGNAL progressReport
void QtContext::progressReport( const char* t0 )
{
    activate_signal( "progressReport(const char*)", t0 );
}

// SIGNAL canStop
void QtContext::canStop( bool t0 )
{
    QConnectionList *clist = receivers("canStop(bool)");
    if ( !clist || signalsBlocked() )
	return;
    typedef void (QObject::*RT0)();
    typedef RT0 *PRT0;
    typedef void (QObject::*RT1)(bool);
    typedef RT1 *PRT1;
    RT0 r0;
    RT1 r1;
    QConnectionListIt it(*clist);
    QConnection   *c;
    QSenderObject *object;
    while ( (c=it.current()) ) {
	++it;
	object = (QSenderObject*)c->object();
	object->setSender( this );
	switch ( c->numArgs() ) {
	    case 0:
		r0 = *((PRT0)(c->member()));
		(object->*r0)();
		break;
	    case 1:
		r1 = *((PRT1)(c->member()));
		(object->*r1)(t0);
		break;
	}
    }
}

// SIGNAL urlChanged
void QtContext::urlChanged( const char* t0 )
{
    activate_signal( "urlChanged(const char*)", t0 );
}
