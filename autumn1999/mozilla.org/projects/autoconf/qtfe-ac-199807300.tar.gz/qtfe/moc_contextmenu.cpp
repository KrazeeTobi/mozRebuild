/****************************************************************************
** ContextMenu meta object code from reading C++ file 'contextmenu.h'
**
** Created: Mon Apr 13 17:18:09 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "contextmenu.h"


const char *ContextMenu::className() const
{
    return "ContextMenu";
}

QMetaObject *ContextMenu::metaObj = 0;

void ContextMenu::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QPopupMenu::metaObject() )
	QPopupMenu::initMetaObject();
    typedef void(ContextMenu::*m1_t0)();
    typedef void(ContextMenu::*m1_t1)();
    typedef void(ContextMenu::*m1_t2)();
    typedef void(ContextMenu::*m1_t3)();
    typedef void(ContextMenu::*m1_t4)();
    typedef void(ContextMenu::*m1_t5)();
    typedef void(ContextMenu::*m1_t6)();
    typedef void(ContextMenu::*m1_t7)();
    m1_t0 v1_0 = &ContextMenu::goAway;
    m1_t1 v1_1 = &ContextMenu::openLinkWindow;
    m1_t2 v1_2 = &ContextMenu::sendPage;
    m1_t3 v1_3 = &ContextMenu::viewImage;
    m1_t4 v1_4 = &ContextMenu::saveLinkAs;
    m1_t5 v1_5 = &ContextMenu::saveImageAs;
    m1_t6 v1_6 = &ContextMenu::copyLinkLocation;
    m1_t7 v1_7 = &ContextMenu::copyImageLocation;
    QMetaData *slot_tbl = new QMetaData[8];
    slot_tbl[0].name = "goAway()";
    slot_tbl[1].name = "openLinkWindow()";
    slot_tbl[2].name = "sendPage()";
    slot_tbl[3].name = "viewImage()";
    slot_tbl[4].name = "saveLinkAs()";
    slot_tbl[5].name = "saveImageAs()";
    slot_tbl[6].name = "copyLinkLocation()";
    slot_tbl[7].name = "copyImageLocation()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    slot_tbl[2].ptr = *((QMember*)&v1_2);
    slot_tbl[3].ptr = *((QMember*)&v1_3);
    slot_tbl[4].ptr = *((QMember*)&v1_4);
    slot_tbl[5].ptr = *((QMember*)&v1_5);
    slot_tbl[6].ptr = *((QMember*)&v1_6);
    slot_tbl[7].ptr = *((QMember*)&v1_7);
    metaObj = new QMetaObject( "ContextMenu", "QPopupMenu",
	slot_tbl, 8,
	0, 0 );
}
