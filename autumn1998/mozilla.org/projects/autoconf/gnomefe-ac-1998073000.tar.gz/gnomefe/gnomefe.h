/* gnomefe misc defs. */

#ifndef _gnome_fe_h
#define _gnome_fe_h

typedef struct fe_ContextData {
    void *frame_or_view;
} fe_ContextData;

#endif /* _gnome_fe_h */
