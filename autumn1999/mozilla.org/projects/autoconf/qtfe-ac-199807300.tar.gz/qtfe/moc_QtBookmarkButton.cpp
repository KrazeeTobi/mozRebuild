/****************************************************************************
** QtBookmarkButton meta object code from reading C++ file 'QtBookmarkButton.h'
**
** Created: Mon Apr 13 17:18:44 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "QtBookmarkButton.h"


const char *QtBookmarkButton::className() const
{
    return "QtBookmarkButton";
}

QMetaObject *QtBookmarkButton::metaObj = 0;

void QtBookmarkButton::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QToolButton::metaObject() )
	QToolButton::initMetaObject();
    typedef void(QtBookmarkButton::*m1_t0)(bool);
    typedef void(QtBookmarkButton::*m1_t1)();
    m1_t0 v1_0 = &QtBookmarkButton::beenToggled;
    m1_t1 v1_1 = &QtBookmarkButton::menuDied;
    QMetaData *slot_tbl = new QMetaData[2];
    slot_tbl[0].name = "beenToggled(bool)";
    slot_tbl[1].name = "menuDied()";
    slot_tbl[0].ptr = *((QMember*)&v1_0);
    slot_tbl[1].ptr = *((QMember*)&v1_1);
    metaObj = new QMetaObject( "QtBookmarkButton", "QToolButton",
	slot_tbl, 2,
	0, 0 );
}
