/****************************************************************************
** QtGrid meta object code from reading C++ file 'qtgrid.h'
**
** Created: Sun May 31 02:13:51 1998
**      by: The Qt Meta Object Compiler ($Revision: 2.9 $)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#if !defined(Q_MOC_OUTPUT_REVISION)
#define Q_MOC_OUTPUT_REVISION 2
#elif Q_MOC_OUTPUT_REVISION != 2
#error Moc format conflict - please regenerate all moc files
#endif

#include <qmetaobj.h>
#include "qtgrid.h"


const char *QtGrid::className() const
{
    return "QtGrid";
}

QMetaObject *QtGrid::metaObj = 0;

void QtGrid::initMetaObject()
{
    if ( metaObj )
	return;
    if ( !QWidget::metaObject() )
	QWidget::initMetaObject();
    metaObj = new QMetaObject( "QtGrid", "QWidget",
	0, 0,
	0, 0 );
}
